import json
import boto3
import logging
import os
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")
cw = boto3.client("cloudwatch")

NAMESPACE = "ReviewAnalyzer"
FUNC_NAME = os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "process-reviews")

def _summarize(reviews):
    """Compute simple stats from a list of objects with a 'review' field."""
    texts = [str(r.get("review", "")) for r in reviews]
    n = len(texts)
    if n == 0:
        return {"count": 0, "avg_char_len": 0.0, "avg_word_len": 0.0}
    char_lens = [len(t) for t in texts]
    word_lens = [len(t.split()) for t in texts]
    return {
        "count": n,
        "avg_char_len": sum(char_lens) / n,
        "avg_word_len": sum(word_lens) / n
    }

def _put_metrics(bucket, key, summary):
    """Emit custom metrics to CloudWatch."""
    dims = [
        {"Name": "FunctionName", "Value": FUNC_NAME},
        {"Name": "Bucket", "Value": bucket},
    ]
    # One PutMetricData with 3 metrics
    cw.put_metric_data(
        Namespace=NAMESPACE,
        MetricData=[
            {
                "MetricName": "ReviewCount",
                "Timestamp": int(time.time()),
                "Value": float(summary["count"]),
                "Unit": "Count",
                "Dimensions": dims,
            },
            {
                "MetricName": "AvgCharLen",
                "Timestamp": int(time.time()),
                "Value": float(summary["avg_char_len"]),
                "Unit": "None",
                "Dimensions": dims,
            },
            {
                "MetricName": "AvgWordLen",
                "Timestamp": int(time.time()),
                "Value": float(summary["avg_word_len"]),
                "Unit": "None",
                "Dimensions": dims,
            },
        ],
    )

def handler(event, context):
    # Expecting an S3 put event
    try:
        rec = event["Records"][0]
        bucket = rec["s3"]["bucket"]["name"]
        key = rec["s3"]["object"]["key"]
        logger.info(f"Triggered by s3://{bucket}/{key}")
    except Exception as e:
        logger.exception("Malformed event")
        return {"error": "malformed_event", "details": str(e)}

    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        body = obj["Body"].read()
        reviews = json.loads(body)  # expecting a JSON array of objects
        summary = _summarize(reviews)

        logger.info(
            f"Processed {summary['count']} reviews | "
            f"avg_char_len={summary['avg_char_len']:.2f} | "
            f"avg_word_len={summary['avg_word_len']:.2f}"
        )

        # Emit metrics
        _put_metrics(bucket, key, summary)

        # (Optional) Write processed summary (keep if you added yesterday)
        # out_key = key.replace("incoming/", "processed/", 1)
        # s3.put_object(
        #     Bucket=bucket,
        #     Key=out_key,
        #     Body=json.dumps(summary).encode("utf-8"),
        #     ContentType="application/json"
        # )
        # logger.info(f"Wrote summary to s3://{bucket}/{out_key}")

        return summary
    except Exception as e:
        logger.exception("Processing failed")
        return {"error": "processing_failed", "details": str(e)}
